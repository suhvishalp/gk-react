import React from "react";

const App = props => (
  <div>
    <h1>My App</h1>
    <br />
    Hello React!
  </div>
);

export default App;
