import React from 'react';
import {UncontrolledForm} from './UncontrolledForm';
import './App.css';

function App() {
  return (
  <div className="App">
    <UncontrolledForm/>
  </div>
  );
}
export default App; 
