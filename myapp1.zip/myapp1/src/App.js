import logo from './logo.svg';
import './App.css';
import NavbarComponent from './components/NavbarComponent';
import Sidebar from './components/Sidebar';
import CourseList from './components/CourseList';

function App() {
  return (
   <div className='container-fluid d-flex flex-column vh-100 p-0'>

      <div class='row' style={ {background:'#C7F9CC'} }>
        <div class='col'>
            <NavbarComponent />
        </div>
      </div>


      <div className='row flex-grow-1'>
          <div className='col-3' style={ {background: '#38A3A5'} }>
              <Sidebar />
          </div>  
          <div className='col-9'  style={ {background: '#C7F9CC'} }>
              <CourseList />
          </div>
      </div>

   </div>
  );
}

export default App;
