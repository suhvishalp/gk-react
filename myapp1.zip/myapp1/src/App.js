import logo from './logo.svg';
import './App.css';
import NavbarComponent from './components/NavbarComponent';
import Sidebar from './components/Sidebar';
import CourseList from './components/CourseList';
import { Route, Routes } from 'react-router-dom';
import HomeComponent from './components/HomeComponent';
import EnrollmentForm from './components/EnrollmentForm';
import ViewCourseDetails from './components/ViewCourseDetails';
import UsersList from './components/UsersList';

function App() {
  return (
   <div className='container-fluid d-flex flex-column vh-100 p-0'>

      <div class='row' style={ {background:'#C7F9CC'} }>
        <div class='col'>
            <NavbarComponent />
        </div>
      </div>


      <div className='row flex-grow-1'>
          <div className='col-3' style={ {background: '#38A3A5'} }>
              <Sidebar />
          </div>  
          <div className='col-9'  style={ {background: '#C7F9CC'} }>
              {/* <CourseList /> */}
              <Routes>

                  <Route path='/enroll/:id' element={ <EnrollmentForm /> }  />

                  <Route path='/courselist' element={ <CourseList/> }  />

                  <Route path='/viewcourse/:id' element={ <ViewCourseDetails/> }  />

                  <Route path='/' element={ <UsersList /> }  />

              </Routes>
          </div>
      </div>

   </div>
  );
}

export default App;
