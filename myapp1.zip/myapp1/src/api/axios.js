import axios from "axios"

 const api = axios.create({
    baseURL: 'https://reqres.in/',
    headers: {
        'x-api-key': 'reqres-free-v1'
    }
})

export const getUsersList = () => {
    return api.get('/api/users?page=2');
}
