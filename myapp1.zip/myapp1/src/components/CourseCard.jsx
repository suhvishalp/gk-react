import React from 'react';

const CourseCard = ({course, onSelect}) => {
     
    return (
       
        <div onClick={()=>onSelect(course.courseId)} className="card" style={ {width: '18rem', display:'block', margin:'10px'}} >
                <img src="..." className="card-img-top" alt="..." />
                <div className="card-body">
                    <h5 className="card-title">{course.title}</h5>
                    <p className="card-text"> {course.description} Some quick example text to build on the card title and make up the bulk of the card’s content.</p>
                    <p className="card-text">{course.startDate}</p>
                    <button href="#" className="btn btn-primary">View Details</button>
                    <button href="#" className="btn btn-primary">Enroll</button>
                    
                </div>
            </div>
       
    );
};

export default CourseCard;