import React from 'react';

function CourseList(props) {
    return (
        <div>
            <h2>Course list is coming soon!</h2>
        </div>
    );
}

export default CourseList;