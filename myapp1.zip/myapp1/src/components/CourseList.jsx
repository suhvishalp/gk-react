import React, { useContext, useState } from 'react';
import CourseCard from './CourseCard';
import { CourseContext } from '../context/CourseContext';

function CourseList(props) {


    //store some data in to 'state' - imagine you get this course data from some backend
    // const [courses, setCourses] = useState([
    //     {courseId: 1, title: 'React JS', description: 'ReactJS course description', startDate: 'July 2, 2025'},
    //     {courseId: 2, title: 'Advanced ReactJS ', description: 'Advanced ReactJS course description', startDate: 'July 7, 2025'},
    //     {courseId: 3, title: 'React Native', description: 'React Native course description', startDate: 'July 21, 2025'}
    // ])


    //fetch the course data from CourseContext 
    const {courses, setCourses} = useContext(CourseContext)

    const [selectedCourse, setSelectedCourse] = useState(null)

    const handleCourseSelect = (id) => {
        const course = courses.find(item => item.courseId === id)
        setSelectedCourse(course)
    }


    return (
        <div>
            <h1>CourseList</h1>
            {selectedCourse && <p>Selected Course: {selectedCourse.title}</p>} 

            {!selectedCourse && <p>Please Select a course</p>} 
           
         
           

            <hr />

            <div className='d-flex flex-wrap'>
                {
                    courses.map((item)=>  <CourseCard 
                                                key={item.courseId} 
                                                course={item} 
                                                onSelect={handleCourseSelect}/>)
                                           
                }
                </div>
               

                

        </div>
    );
}

export default CourseList;