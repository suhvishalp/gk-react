import React, { useContext } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import { CourseContext } from '../context/CourseContext';
import { useForm } from 'react-hook-form';

const EnrollmentForm = () => {

    const {id} =  useParams()
    const {courses} = useContext(CourseContext)
    const navigate = useNavigate()


    const course = courses.find(item => item.courseId === Number(id))

    // if(!id) return <p>Select a course to enroll</p>


    const {register, handleSubmit, formState: {errors, isSubmitting, isSubmitSuccessful} } = useForm({
                    defaultValues: {
                        firstName: '',
                        lastName: '',
                        email:'',
                        courseTitle: course.title
                    }
                })

    const handleEnrollSubmit = (data) => {
        console.log('Form is submitted', data)
        //logic to send this data to backend
        //after successfull processing from backend - navigate congratulation message
    }
    
    if (!course) return <p>Course Not Found</p>

    return (
        <div>
            <h1>Enrollment Form</h1>
            <h3>You are enrolling into {course.title} course!</h3>

            <form onSubmit={ handleSubmit(handleEnrollSubmit) }>
                <div className="mb-3">
                    <label for="fname" className="form-label">First Name</label>
                    <input 
                        type="text" 
                        className="form-control" 
                        id="firstName" 
                            { ...register('firstName', {required: 'First Name is required', minLength: {value:5, message:'First Should atleast haeve 5 characters'} } ) }
                        />
                     { errors.firstName && <div className="alert alert-danger">{errors.firstName.message}</div> }
                     { errors.minLength && <div className="alert alert-danger">{errors.minLength.message}</div> }
                </div>
             
                <div className="mb-3">
                    <label for="lname" className="form-label">Last Name</label>
                    <input type="text" className="form-control" id="lastName" 
                            { ...register('lastName') }/>
                </div>

                <div className="mb-3">
                    <label for="email" className="form-label">Email</label>
                    <input type="email" className="form-control" id="email" 
                            { ...register('email') }
                    />
                </div>

                <div className="mb-3">
                    <label for="course" className="form-label">Course Title</label>
                    <input type="text" readOnly className="form-control" id="courseTitle"
                            { ...register('courseTitle') }
                     />
                </div>
            
                <div className="mb-3">
                    <button type="submit" className="btn btn-primary">Submit</button>
                </div>
            </form>

        </div>
    );
};

export default EnrollmentForm;