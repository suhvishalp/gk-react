import React from 'react';

const HomeComponent = () => {
    return (
        <div>
            <h1>Home Component</h1>
        </div>
    );
};

export default HomeComponent;