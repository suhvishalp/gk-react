
export default function NavbarComponent() {
    return (
        <nav class="navbar navbar-expand-lg navbar-dark bg-primary">
            <a className="navbar-brand" href="#">Global Knowledge</a>
        </nav>
    )
}