import { useContext } from "react"
import { CourseContext } from "../context/CourseContext"

export default function NavbarComponent() {

    const {courses, setCourses} = useContext(CourseContext)

    return (
        <nav className="navbar navbar-expand-lg navbar-dark bg-primary">
            <a className="navbar-brand" href="/">Global Knowledge</a>

            <ul class="navbar-nav">

                <li class="nav-item">
                    <a class="nav-link" href="/">Home</a>
                </li>

                <li class="nav-item">
                    <a class="nav-link active" aria-current="page" href="/courselist">CourseList</a>
                </li>
                
                <li class="nav-item">
                    <a class="nav-link" href="/enroll">Enrollment</a>
                </li>
            </ul>

            <div className="container-fluid">
                <span className="navbar-text">
                    Total Courses: <span class="badge text-bg-light">{courses.length}</span>
                </span>
            </div>
        </nav>
    )
}