import React from 'react';

function Sidebar(props) {

    const courseCategories  = ['FrontEnd', 'Backend', 'Database', 'UI Design']

    return (
        <div>
            <ul class="list-group">
               {
                    courseCategories.map((item, index)=>{
                        return <li key={index} class="list-group-item">{item}</li>
                    })
               }
            </ul>
        </div>
    );
}

export default Sidebar;