import React, { useEffect, useState } from 'react';
import { api, getUsersList } from '../api/axios';

const UsersList = () => {

    const { userData, setUserData} = useState([]);

    useEffect(()=>{

        //write the logic to make side effects i.e. api calls / ajax calls / http requests



        const getUsers = async () => {

            const results = await getUsersList();
            console.log(results)

            // const response = await fetch('https://reqres.in/api/users?page=2', {
            //                         headers: {
            //                             'x-api-key': 'reqres-free-v1'
            //                         }
            //                     });
            // const list = await response.json();
            // console.log('response ', list)
        }

        getUsers();

        // fetch('https://reqres.in/api/users?page=2', {
        //     headers: {
        //         'x-api-key': 'reqres-free-v1'
        //     }
        // })
        //     .then((response)=>{
        //         console.log('response is received', response) 
        //         return response.json()
        //     })
        //     .then((userdata)=>{
        //         console.log('users data', userdata)
        //         setUserData(userdata.data)
        //     })
        //     .catch((error)=>{
        //         console.log('something went wrong', error) 
        //     })

    }, [])

    return (
        <div>
            <h1>Users List</h1>
            
        </div>
    );
};

export default UsersList;