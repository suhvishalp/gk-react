import React, { useContext } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import { CourseContext } from '../context/CourseContext';

const ViewCourseDetails = () => {

    const {id} =  useParams()
    const {courses} = useContext(CourseContext)
    const navigate = useNavigate()

    const course = courses.find(item => item.courseId === Number(id))

    if (!course) return <p>Course Not Found</p>

    return (
        <div>
            <h1>View Course Details</h1>
            <p>Course Id: {id}</p>  
            <p>Title: {course.title}</p>
            <p>Description: {course.description}</p>
            <p>Start Date: {course.startDate}</p>

            <button onClick={ ()=> navigate(`/enroll/${course.courseId}`)} className="btn btn-primary">Enroll</button>
        </div>
    );
};

export default ViewCourseDetails;