import { createContext, useState } from "react";


//1.create a new context - using context we can share the data globally
export const CourseContext = createContext();


//2. build the provider and decide what data you want to share
export const CourseProvider = ({children}) => {

    //data we want to provide to the children
    const [courses, setCourses] = useState([
        {courseId: 1, title: 'React JS', description: 'ReactJS course description', startDate: 'July 2, 2025'},
        {courseId: 2, title: 'Advanced ReactJS ', description: 'Advanced ReactJS course description', startDate: 'July 7, 2025'},
        {courseId: 3, title: 'React Native', description: 'React Native course description', startDate: 'July 21, 2025'}
    ])

    return (
        <CourseContext.Provider value={ {courses, setCourses} }>
            {children}
        </CourseContext.Provider>
    )


}